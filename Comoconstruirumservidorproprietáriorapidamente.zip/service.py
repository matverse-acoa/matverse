from __future__ import annotations

from typing import Any, Dict, List

from .config import STACK_API_URL
from .ledger import Ledger, LedgerEntry
from .memory import GeometricMemory, MNB
from .sgsi import SGSI
from .upstream import UpstreamAPI


class MatVerseService:
    def __init__(self):
        self.memory = GeometricMemory()
        self.ledger = Ledger()
        self.upstream_api = UpstreamAPI()
        self.sgsi = SGSI()

    def process_query(self, query: str, top_k: int = 3, add_to_memory: bool = False, metadata: Dict[str, Any] = {}) -> Dict[str, Any]:
        # 1. Query upstream API or use local fallback
        upstream_result = self.upstream_api.process_query(query, top_k)

        # 2. Process with SGSI
        sgsi_input = {
            "type": "process_query",
            "stimulus": {"query": query, "top_k": top_k, "metadata": metadata},
            "context": {"upstream_mode": upstream_result["mode"]},
            "losses": [1.0] if upstream_result["mode"] != "remote_ok" else [], # Inject loss if remote failed
            "latency_ms": 0, # Placeholder
            "replay_ok": False, # Default for now
            "receipt_ok": False, # Default for now
            "publication_ok": False, # Default for now
        }
        sgsi_result = self.sgsi.process(sgsi_input)

        # 3. Add to memory if requested and SGSI allows
        mnb: Optional[MNB] = None
        if add_to_memory and sgsi_result["governance"]["decision"] != "BLOCK":
            mnb = self.memory.add(
                content=upstream_result["answer"],
                source=metadata.get("source", "process_query"),
                metadata=metadata
            )
            sgsi_result["skill"]["mutation_applied"] = True
            sgsi_result["skill"]["new_mnb_id"] = mnb.mnb_id

        # 4. Record event in ledger
        ledger_payload = {
            "query": query,
            "upstream_result": upstream_result,
            "sgsi_result": sgsi_result,
            "mnb_added": mnb.model_dump() if mnb else None,
        }
        self.ledger.add_entry("query_processed", ledger_payload)

        return {
            "query": query,
            "answer": upstream_result["answer"],
            "sgsi_decision": sgsi_result["governance"]["decision"],
            "sgsi_metrics": sgsi_result["metrics"],
            "mnb_id": mnb.mnb_id if mnb else None,
            "ledger_entry": self.ledger.entries[-1].model_dump(),
        }

    def add_mnb(self, content: str, source: str, metadata: Dict[str, Any]) -> MNB:
        mnb = self.memory.add(content, source, metadata)
        self.ledger.add_entry("mnb_added", mnb.model_dump())
        return mnb

    def search_memory(self, query: str, top_k: int = 5) -> List[MNB]:
        return self.memory.search(query, top_k)

    def get_mnb(self, mnb_id: str) -> Optional[MNB]:
        return self.memory.get(mnb_id)

    def get_ledger(self) -> List[LedgerEntry]:
        return self.ledger.get_all_entries()

    def get_health(self) -> Dict[str, Any]:
        return {
            "status": "ok",
            "memory_path": str(self.memory.path),
            "ledger_path": str(self.ledger.path),
            "stack_api_configured": bool(STACK_API_URL),
            "memory_items": len(self.memory.items),
            "ledger_entries": len(self.ledger.entries),
        }
