from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, List

from pydantic import BaseModel, Field

from .config import LEDGER_PATH
from .utils import safe_append_jsonl


class LedgerEntry(BaseModel):
    timestamp: float = Field(default_factory=time.time)
    event_type: str
    payload: Dict[str, Any]
    prev_hash: str = ""
    entry_hash: str = ""

    def calculate_hash(self) -> str:
        data = json.dumps(
            {
                "timestamp": self.timestamp,
                "event_type": self.event_type,
                "payload": self.payload,
                "prev_hash": self.prev_hash,
            },
            sort_keys=True,
            ensure_ascii=False,
        )
        return hashlib.sha256(data.encode("utf-8")).hexdigest()


class Ledger:
    def __init__(self, path: Path = LEDGER_PATH):
        self.path = path
        self.entries: List[LedgerEntry] = []
        self._load()

    def _load(self) -> None:
        if self.path.exists():
            with self.path.open("r", encoding="utf-8") as f:
                for line in f:
                    self.entries.append(LedgerEntry(**json.loads(line)))

    def add_entry(self, event_type: str, payload: Dict[str, Any]) -> LedgerEntry:
        prev_hash = self.entries[-1].entry_hash if self.entries else "0" * 64
        entry = LedgerEntry(event_type=event_type, payload=payload, prev_hash=prev_hash)
        entry.entry_hash = entry.calculate_hash()
        self.entries.append(entry)
        safe_append_jsonl(self.path, entry.model_dump())
        return entry

    def get_all_entries(self) -> List[LedgerEntry]:
        return self.entries
